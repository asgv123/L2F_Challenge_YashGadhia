clear functions;clear all;
disp('JSBSim S-Function Reset')